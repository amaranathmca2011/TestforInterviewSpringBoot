package com.beyond.bytes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication

@ComponentScan(basePackages = { "com.beyond.controller","com.beyond.service" })
@EntityScan(basePackages = {"com.beyond.pojo"})
@EnableJpaRepositories(basePackages = {"com.beyond.dao"})
public class BeyondBytesApplication extends SpringBootServletInitializer{

	/*@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(BeyondBytesApplication.class);
    }*/
	public static void main(String[] args) {
		SpringApplication.run(BeyondBytesApplication.class, args);
	}
}

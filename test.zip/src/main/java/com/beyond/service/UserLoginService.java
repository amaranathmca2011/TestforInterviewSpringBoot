package com.beyond.service;

import com.beyond.pojo.LoginEntity;

public interface UserLoginService {

	LoginEntity checkUserDetails(LoginEntity login);

}
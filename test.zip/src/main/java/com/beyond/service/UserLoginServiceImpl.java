package com.beyond.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beyond.dao.LoginDaoRepository;
import com.beyond.pojo.LoginEntity;

@Service
public class UserLoginServiceImpl implements UserLoginService{

	@Autowired
	private LoginDaoRepository loginDaoRepository;
	
	@Override
	public LoginEntity checkUserDetails(LoginEntity login) {
		
		return loginDaoRepository.findUser(login.getUsername(), login.getPassword());
		 
	}

}
